<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

$host = 'localhost';
$db = 'home_hoa';
$user = 'root'; // Change this to your MySQL username
$pass = ''; // Change this to your MySQL password

// Create a connection
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle GET request to fetch messages
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $result = $conn->query("SELECT * FROM messages ORDER BY timestamp ASC");
    $messages = $result->fetch_all(MYSQLI_ASSOC);
    echo json_encode($messages);
}

// Handle POST request to send a message
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);
    $sender = $data['sender'];
    $content = $data['content'];

    $stmt = $conn->prepare("INSERT INTO messages (sender, content) VALUES (?, ?)");
    $stmt->bind_param("ss", $sender, $content);
    $stmt->execute();
    $stmt->close();

    echo json_encode(['status' => 'Message sent']);
}

$conn->close();
?>