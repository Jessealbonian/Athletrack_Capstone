<?php
header("Access-Control-Allow-Origin: *");
echo "Hello, World!";
?>