<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, DELETE, PUT, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

// Handle OPTIONS request for preflight check
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD'])) {
        header("Access-Control-Allow-Methods: GET, POST, DELETE, PUT, OPTIONS");
    }
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS'])) {
        header("Access-Control-Allow-Headers: Content-Type, Authorization");
    }
    exit(0);
}

// Include required modules
header("access-control-allow-origin: *");
require_once "./modules/get.php";
require_once "./modules/post.php";
require_once "./config/database.php";

$con = new Connection();
$pdo = $con->connect();

// Initialize Get and Post objects
$get = new Get($pdo);
$post = new Post($pdo);

// Check if 'request' parameter is set in the request
if (isset($_REQUEST['request'])) {
    // Split the request into an array based on '/'
    $request = explode('/', $_REQUEST['request']);
} else {
    // If 'request' parameter is not set, return a 404 response
    echo "Not Found";
    http_response_code(404);
}

// Handle requests based on HTTP method
switch ($_SERVER['REQUEST_METHOD']) {
        // Handle GET requests
    case 'GET':
        switch ($request[0]) {
            case 'todolist':
                // Return JSON-encoded data for getting employees
                if (count($request) > 1) {
                    echo json_encode($get->getstatus($request[1]));
                } else {
                    echo json_encode($get->getstatus($data));
                }
                break;



            case '1todolist':
                // Return JSON-encoded data for getting jobs
                if (count($request) > 1) {
                    echo json_encode($get->gettask($request[1]));
                } else {
                    echo json_encode($get->gettask($data));
                }
                break;


            case 'todoliststatus':
                // Return JSON-encoded data for getting jobs
                if (count($request) > 1) {
                    echo json_encode($get->gettask_status($request[1]));
                } else {
                    echo json_encode($get->gettask_status($data));
                }
                break;

                // HOME_HOA

            case 'get_properties':
                echo json_encode($get->get_properties());
                break;

            case 'getMedia':
                echo json_encode($get->getMedia());
                break;

            case 'get_media':
                if (count($request) > 1) {
                    echo json_encode($get->get_Media($request[1]));
                } else {
                    echo json_encode($get->get_Media('news')); // Default to news if no type is provided
                }
                break;


            default:
                // Return a 403 response for unsupported requests
                echo "This is forbidden";
                http_response_code(403);
                break;
        }
        break;
        // Handle POST requests    
    case 'POST':
        // Retrieves JSON-decoded data from php://input using file_get_contents
        $data = json_decode(file_get_contents("php://input"));
        switch ($request[0]) {


            case 'delete_task':
                // Return JSON-encoded data for adding employees
                echo json_encode($post->delete_employees($request[1]));
                break;

            case 'addjob':
                // Return JSON-encoded data for adding jobs
                echo json_encode($post->add_jobs($data));
                break;

            case 'add_task': //done working
                echo json_encode($post->add_task($data, $request[1]));
                break;

            case 'updatetask': //done working
                echo json_encode($post->edit_taskk($data, $request[1]));
                break;

            case 'change_status': //done working
                echo json_encode($post->bagostatus($data, $request[1]));
                break;

            case 'update_task_order': // new route
                echo json_encode($post->updateangOrder($data, $request[1]));
                break;
                //LOGIN SIGN UP
            case 'signup':
                echo $post->signup($data);
                break;

            case 'login':
                echo $post->login($data);
                break;

                // HOME_HOA  

            case 'add_property': // new route for adding properties
                echo json_encode($post->add_property($data));
                break;

            case 'addNews':
                echo json_encode($post->add_news($data));
                break;

            case 'addEvent':
                echo json_encode($post->add_event($data));
                break;

            case 'addBlog':
                echo json_encode($post->add_blog($data));
                break;

            case 'addVlog':
                echo json_encode($post->add_vlog($data));
                break;

            case 'submitInquiry':
                echo json_encode($post->submitInquiry($data));
                break;

            case 'submitTrippingRequest':
                echo json_encode($post->submitTrippingRequest($data));
                break;

            case 'submitCustomerCare':
                echo json_encode($post->submitCustomerCare($data));
                break;

            case 'submitTurnOver':
                echo json_encode($post->submitTurnOver($data));
                break;

            default:
                // Return a 403 response for unsupported requests
                echo "This is forbidden";
                http_response_code(403);
                break;
        }
        break;

    default:
        // Return a 404 response for unsupported HTTP methods
        echo "Method not available";
        http_response_code(404);
        break;
}
