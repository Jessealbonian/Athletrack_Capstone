<?php

/**
 * Post Class
 *
 * This PHP class provides methods for adding employees and jobs.
 *
 * Usage:
 * 1. Include this class in your project.
 * 2. Create an instance of the class to access the provided methods.
 * 3. Call the appropriate method to add new employees or jobs with the provided data.
 *
 * Example Usage:
 * ```
 * $post = new Post();
 * $employeeData = ... // prepare employee data as an associative array or object
 * $addedEmployee = $post->add_employees($employeeData);
 *
 * $jobData = ... // prepare job data as an associative array or object
 * $addedJob = $post->add_jobs($jobData);
 * ```
 *
 * Note: Customize the methods as needed to handle the addition of data to your actual data source (e.g., database, API).
 */

use Firebase\JWT\JWT;

require_once("global.php");
require 'vendor/autoload.php';
class Post extends GlobalMethods
{

    private $pdo;

    public function __construct(\PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    public function login($data)
    {
        $secret_key = "63448c0f19663276ceabdc626d7aab8855872cc7ef5b152d099c41dcbbccd4ce"; // Use your secret key here
        $issuer_claim = "http://localhost";
        $audience_claim = "http://localhost";
        $issuedat_claim = time();
        $notbefore_claim = $issuedat_claim + 10;
        $expire_claim = $issuedat_claim + 3600;

        if (isset($data->email) && isset($data->password)) {
            $email = $data->email;
            $password = $data->password;

            $stmt = $this->pdo->prepare("SELECT * FROM users WHERE email = :email");
            $stmt->bindParam(':email', $email);
            $stmt->execute();

            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && password_verify($password, $user['password'])) {
                $token = array(
                    "iss" => $issuer_claim,
                    "aud" => $audience_claim,
                    "iat" => $issuedat_claim,
                    "nbf" => $notbefore_claim,
                    "exp" => $expire_claim,
                    "data" => array(
                        "id" => $user['user_id'],
                        "email" => $user['email']
                    )
                );

                $jwt = JWT::encode($token, $secret_key, 'HS256');

                return json_encode(array(
                    "message" => "Login successful",
                    "jwt" => $jwt,
                    "email" => $email,
                    "expireAt" => $expire_claim
                ));
            } else {
                http_response_code(401);
                return json_encode(array("message" => "Invalid email or password"));
            }
        } else {
            http_response_code(400);
            return json_encode(array("message" => "Email and password are required"));
        }
    }

    public function signup($data)
    {
        $secret_key = "63448c0f19663276ceabdc626d7aab8855872cc7ef5b152d099c41dcbbccd4ce";
        $issuer_claim = "http://localhost";
        $audience_claim = "http://localhost";
        $issuedat_claim = time();
        $notbefore_claim = $issuedat_claim + 10;
        $expire_claim = $issuedat_claim + 3600;

        if (isset($data->username) && isset($data->email) && isset($data->password)) {
            $username = $data->username;
            $email = $data->email;
            $password = password_hash($data->password, PASSWORD_BCRYPT);

            $stmt = $this->pdo->prepare("SELECT * FROM users WHERE email = :email");
            $stmt->bindParam(':email', $email);
            $stmt->execute();

            if ($stmt->rowCount() > 0) {
                http_response_code(409);
                return json_encode(["message" => "Email already exists"]);
            } else {
                $stmt = $this->pdo->prepare("INSERT INTO users (username, email, password) VALUES (:username, :email, :password)");
                $stmt->bindParam(':username', $username);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':password', $password);

                if ($stmt->execute()) {
                    $user_id = $this->pdo->lastInsertId();
                    $token = array(
                        "iss" => $issuer_claim,
                        "aud" => $audience_claim,
                        "iat" => $issuedat_claim,
                        "nbf" => $notbefore_claim,
                        "exp" => $expire_claim,
                        "data" => array(
                            "id" => $user_id,
                            "username" => $username,
                            "email" => $email
                        )
                    );

                    $jwt = JWT::encode($token, $secret_key, 'HS256');
                    return json_encode(
                        array(
                            "message" => "Signup successful",
                            "jwt" => $jwt,
                            "username" => $username,
                            "email" => $email,
                            "expireAt" => $expire_claim
                        )
                    );
                } else {
                    http_response_code(500);
                    return json_encode(["message" => "Internal server error"]);
                }
            }
        } else {
            http_response_code(400);
            return json_encode(["message" => "Username, email, and password are required"]);
        }
    }

    public function add_task($data, $id)
    {
        $errrmsg = "";
        $code = 0;
        $sql = "INSERT INTO todolist(
                task, description, due_date, status, user_id)
                VALUES (?,?,?,?,?)
                ";
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute(
                [

                    $data->task,
                    $data->description,
                    $data->due_date,
                    $data->status,
                    $id,


                ]
            );
            return $this->sendPayload(null, "success", "succesfully updated data", $code);
        } catch (\PDOException $e) {
            $errmsg = $e->getMessage();
            $code = 400;
        }
        return $this->sendPayload(null, "failed", $errmsg, $code);
    }

    public function edit_taskk($data, $id)
    {
        $errrmsg = "";
        $code = 0;
        $sql = "UPDATE todolist set task=?, description=?, due_date=?, status=?
                    WHERE id=?";

        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute(
                [
                    $data->task,
                    $data->description,
                    $data->due_date,
                    $data->status,
                    $id,
                ]
            );
            return $this->sendPayload(null, "success", "succesfully updated data", $code);
        } catch (\PDOException $e) {
            $errmsg = $e->getMessage();
            $code = 400;
        }
        return $this->sendPayload(null, "failed", $errmsg, $code);
    }

    public function delete_employees($id)
    {
        $errmsg = "";
        $code = 0;
        $sql = "DELETE FROM todolist WHERE id=?";

        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute(
                [
                    $id
                ]
            );
            return $this->sendPayload(null, "success", "Successfully deleted employee", $code);
        } catch (\PDOException $e) {
            $errmsg = $e->getMessage();
            $code = 400;
        }
        return $this->sendPayload(null, "failed", $errmsg, $code);
    }

    public function update_task_status($taskId, $status)
    {
        $errmsg = "";
        $code = 0;
        $sql = "UPDATE todolist SET status=? WHERE id=?";

        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$status, $taskId]);
            return $this->sendPayload(null, "success", "Task status updated successfully", $code);
        } catch (\PDOException $e) {
            $errmsg = $e->getMessage();
            $code = 400;
        }
        return $this->sendPayload(null, "failed", $errmsg, $code);
    }

    public function bagostatus($data, $id)
    {
        $sql = "UPDATE todolist
                        SET 
                            status = ?
                        WHERE
                            id = ?;";
        try {
            $statement = $this->pdo->prepare($sql);
            $statement->execute(
                [
                    $data->status,
                    $id
                ]
            );
            return $this->sendPayload(null, "success", "Successfully updated task.", 200);
        } catch (\PDOException $e) {
            $errmsg = $e->getMessage();
            $code = 400;
        }

        return $this->sendPayload(null, "failed", $errmsg, $code);
    }

    public function updateangOrder($data, $id)
    {
        $sql = "UPDATE todolist SET `order` = :order WHERE id = :id";

        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([
                $data->order,
                $id
            ]);
            return $this->sendPayload(null, "success", "Task status updated successfully", null);
        } catch (\PDOException $e) {
            $errmsg = $e->getMessage();
            $code = 400;
        }
        return $this->sendPayload(null, "failed", $errmsg, $code);
    }

    public function executeQuery($sql)
    {
        $data = array(); //place to store records retrieved for db
        $errmsg = ""; //initialized error message variable
        $code = 0; //initialize status code variable

        try {
            if ($result = $this->pdo->query($sql)->fetchAll()) { //retrieved records from db, returns false if no records found
                foreach ($result as $record) {
                    array_push($data, $record);
                }
                $code = 200;
                $result = null;
                return array("code" => $code, "data" => $data);
            } else {
                //if no record found, assign corresponding values to error messages/status
                $errmsg = "No records found";
                $code = 404;
            }
        } catch (\PDOException $e) {
            //PDO errors, mysql errors
            $errmsg = $e->getMessage();
            $code = 403;
        }
        return array("code" => $code, "errmsg" => $errmsg);
    }

    // HOME_HOA 
    public function add_property()
    {
        try {
            // Create a data object from POST data
            $data = (object) [
                "prop_name" => $_POST['prop_name'] ?? null,
                "prop_address" => $_POST['prop_address'] ?? null,
                "prop_size" => $_POST['prop_size'] ?? null,
                "prop_rooms" => $_POST['prop_rooms'] ?? null,
                "prop_status" => $_POST['prop_status'] ?? null,
                "prop_price" => $_POST['prop_price'] ?? null
            ];
    
            // Validate that all required fields are present
            if (!$data->prop_name || !$data->prop_address || !$data->prop_size || !$data->prop_rooms || !$data->prop_price) {
                throw new Exception("Missing required fields.");
            }
    
            // Define the target directory
            $targetDir = "homes/";
    
            // Handle the image file
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $fileName = basename($_FILES['image']['name']);
                $targetFilePath = $targetDir . $fileName;
    
                // Create directory if it doesn't exist
                if (!is_dir($targetDir)) {
                    mkdir($targetDir, 0777, true);
                }
    
                // Validate file type
                $fileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));
                $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
    
                if (!in_array($fileType, $allowedTypes)) {
                    throw new Exception("Invalid image file type.");
                }
    
                if (!move_uploaded_file($_FILES['image']['tmp_name'], $targetFilePath)) {
                    throw new Exception("Failed to upload the image.");
                }
    
                $data->image = $targetFilePath;
            } else {
                throw new Exception("Image upload error.");
            }
    
            // Prepare SQL statement
            $stmt = $this->pdo->prepare("INSERT INTO properties (image, prop_name, prop_address, prop_size, prop_rooms, prop_status, prop_price) VALUES (?, ?, ?, ?, ?, ?, ?)");
    
            // Bind parameters
            $stmt->bindParam(1, $data->image);
            $stmt->bindParam(2, $data->prop_name);
            $stmt->bindParam(3, $data->prop_address);
            $stmt->bindParam(4, $data->prop_size);
            $stmt->bindParam(5, $data->prop_rooms);
            $stmt->bindParam(6, $data->prop_status);
            $stmt->bindParam(7, $data->prop_price);
    
            // Execute the statement
            if ($stmt->execute()) {
                return json_encode(["message" => "Property added successfully."]);
            } else {
                throw new Exception("Failed to add property.");
            }
        } catch (Exception $e) {
            // Catch any exceptions and return the error message
            return json_encode(["message" => $e->getMessage()]);
        }
    }
    


    public function add_news($data)
    {
        $stmt = $this->pdo->prepare("INSERT INTO news (title, image, description) VALUES (?, ?, ?)");
        $stmt->bindParam(1, $data->title);
        $stmt->bindParam(2, $data->image);
        $stmt->bindParam(3, $data->description);

        if ($stmt->execute()) {
            return json_encode(["message" => "News added successfully."]);
        } else {
            return json_encode(["message" => "Failed to add news."]);
        }
    }

    public function add_event($data)
    {
        $stmt = $this->pdo->prepare("INSERT INTO events (title, image, description) VALUES (?, ?, ?)");
        $stmt->bindParam(1, $data->title);
        $stmt->bindParam(2, $data->image);
        $stmt->bindParam(3, $data->description);

        if ($stmt->execute()) {
            return json_encode(["message" => "Event added successfully."]);
        } else {
            return json_encode(["message" => "Failed to add event."]);
        }
    }

    public function add_blog($data)
    {
        $stmt = $this->pdo->prepare("INSERT INTO blogs (title, image, description) VALUES (?, ?, ?)");
        $stmt->bindParam(1, $data->title);
        $stmt->bindParam(2, $data->image);
        $stmt->bindParam(3, $data->description);

        if ($stmt->execute()) {
            return json_encode(["message" => "Blog added successfully."]);
        } else {
            return json_encode(["message" => "Failed to add blog."]);
        }
    }

    public function add_vlog($data)
    {
        $stmt = $this->pdo->prepare("INSERT INTO vlogs (title, thumbnailUrl, shortDescription) VALUES (?, ?, ?)");
        $stmt->bindParam(1, $data->title);
        $stmt->bindParam(2, $data->thumbnailUrl);
        $stmt->bindParam(3, $data->shortDescription);

        if ($stmt->execute()) {
            return json_encode(["message" => "Vlog added successfully."]);
        } else {
            return json_encode(["message" => "Failed to add vlog."]);
        }
    }

    public function submitInquiry($data)
    {
        try {
            if (!isset($data->name) || !isset($data->email) || 
                !isset($data->phone) || !isset($data->message)) {
                http_response_code(400);
                return json_encode(["message" => "All fields are required"]);
            }

            $sql = "INSERT INTO inquiries (name, email, phone, message) 
                    VALUES (?, ?, ?, ?)";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([
                $data->name,
                $data->email,
                $data->phone,
                $data->message
            ]);

            return json_encode(["message" => "Inquiry submitted successfully"]);
        } catch (\PDOException $e) {
            http_response_code(500);
            return json_encode(["message" => "Failed to submit inquiry: " . $e->getMessage()]);
        }
    }

    public function submitCustomerCare($data)
    {
        try {
            // Validate required fields
            if (
                !isset($data->name) || !isset($data->email) ||
                !isset($data->phone) || !isset($data->concernType) ||
                !isset($data->description)
            ) {
                http_response_code(400);
                return json_encode(["message" => "All fields are required"]);
            }

            $sql = "INSERT INTO customer_care (name, email, phone, concern_type, description) 
                VALUES (?, ?, ?, ?, ?)";

            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([
                $data->name,
                $data->email,
                $data->phone,
                $data->concernType,
                $data->description
            ]);

            return json_encode(["message" => "Customer care request submitted successfully"]);
        } catch (\PDOException $e) {
            http_response_code(500);
            return json_encode(["message" => "Failed to submit customer care request: " . $e->getMessage()]);
        }
    }

    public function submitTurnOver($data)
    {
        try {
            // Validate required fields
            if (
                !isset($data->name) || !isset($data->email) ||
                !isset($data->phone) || !isset($data->unit_number) ||
                !isset($data->date)
            ) {
                http_response_code(400);
                return json_encode(["message" => "All fields are required"]);
            }

            $sql = "INSERT INTO unit_turnover (name, email, phone, unit_number, date, notes) 
                VALUES (?, ?, ?, ?, ?, ?)";

            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([
                $data->name,
                $data->email,
                $data->phone,
                $data->unit_number,
                $data->date,
                $data->notes ?? '' // Notes are optional
            ]);

            return json_encode(["message" => "Turn over request submitted successfully"]);
        } catch (\PDOException $e) {
            http_response_code(500);
            return json_encode(["message" => "Failed to submit turn over request: " . $e->getMessage()]);
        }
    }

    // ... rest of the class ...

    public function submitTrippingRequest($data)
    {
        try {
            // Validate required fields
            if (
                !isset($data->name) || !isset($data->email) ||
                !isset($data->phone) || !isset($data->date) ||
                !isset($data->time) || !isset($data->property_of_interest)
            ) {
                http_response_code(400);
                return json_encode(["message" => "All fields are required"]);
            }

            // Prepare SQL statement
            $sql = "INSERT INTO tripping_request (name, email, phone, date, time, property_of_interest) 
                        VALUES (?, ?, ?, ?, ?, ?)";

            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([
                $data->name,
                $data->email,
                $data->phone,
                $data->date,
                $data->time,
                $data->property_of_interest
            ]);

            return json_encode(["message" => "Tripping request submitted successfully"]);
        } catch (\PDOException $e) {
            http_response_code(500);
            return json_encode(["message" => "Failed to submit tripping request: " . $e->getMessage()]);
        }
    }

    /**
     * Add a new employee with the provided data.
     *
     * @param array|object $data
     *   The data representing the new employee.
     *
     * @return array|object
     *   The added employee data.
     */
    /**
     * Add a new job with the provided data.
     *
     * @param array|object $data
     *   The data representing the new job.
     *
     * @return array|object
     *   The added job data.
     */
    public function add_jobs($data)
    {
        return $data;
    }
}
