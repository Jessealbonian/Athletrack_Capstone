<?php
 require_once("global.php");

class Get extends GlobalMethods {
    private $pdo;

    public function __construct(\PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function executeQuery($sql) {
        $data = array(); // place to store records retrieved for db
        $errmsg = ""; // initialized error message variable
        $code = 0; // initialize status code variable

        try {
            $statement = $this->pdo->query($sql);
            if ($statement) {
                $result = $statement->fetchAll();
                foreach ($result as $record) {
                    $data[] = $record;
                }
                $code = 200;
                return array("code" => $code, "data" => $data);
            } else {
                // if no record found, assign corresponding values to error messages/status
                $errmsg = "No records found";
                $code = 404;
            }
        } catch (\PDOException $e) {
            // PDO errors, mysql errors
            $errmsg = $e->getMessage();
            $code = 403;
        }
        return array("code" => $code, "errmsg" => $errmsg);
    }

    public function sendPayload($data, $remarks, $message, $code){
        $status = array("remarks"=>$remarks, "message"=>$message);
        http_response_code($code);
        return array(
            "status"=>$status,
            "payload"=>$data,
            "prepared_by"=>"Jomar",
            "timestamp"=>date_create()
        );
    }

    public function get_records($table, $condition = null) {
        $sqlString = "SELECT * FROM $table";
        if ($condition != null) {
            $sqlString .= " WHERE " . $condition;
        }

        $result = $this->executeQuery($sqlString);

        if ($result['code'] == 200) {
            return $this->sendPayload($result['data'], "success", "Successfully retrieved records.", $result['code']);
        }

        return $this->sendPayload(null, "failed", "Failed to retrieve records.", $result['code']);
    }

    public function get_employees($id = null) {
        $condition = null;
        if ($id != null) {
            $condition = "EMPLOYEE_ID=$id";
        }
        return $this->get_records("employees", $condition);
    }

    public function getstatus($status) {
        try {
            $sqlString = "SELECT * FROM todolist WHERE user_id = ?";
            $stmt = $this->pdo->prepare($sqlString);

            if (!$stmt) {
                return $this->getResponse(null, "Failed", "Failed to prepare statement", 500);
            }

            $stmt->bindParam(1, $status, PDO::PARAM_STR);

            if (!$stmt->execute()) {
                return $this->getResponse(null, "Failed", "Failed to execute statement", 500);
            }

            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if ($result) {
                return $this->getResponse($result, "Success", null, 200);
            } else {
                return $this->getResponse(null, "Failed", "No records found", 404);
            }
        } catch (Exception $e) {
            return $this->getResponse(null, "Failed", "Exception: " . $e->getMessage(), 500);
        }
    }

    public function gettask($status) {
        try {
            $sqlString = "SELECT * FROM todolist WHERE id = ?";
            $stmt = $this->pdo->prepare($sqlString);

            if (!$stmt) {
                return $this->getResponse(null, "Failed", "Failed to prepare statement", 500);
            }

            $stmt->bindParam(1, $status, PDO::PARAM_STR);

            if (!$stmt->execute()) {
                return $this->getResponse(null, "Failed", "Failed to execute statement", 500);
            }

            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if ($result) {
                return $this->getResponse($result, "Success", null, 200);
            } else {
                return $this->getResponse(null, "Failed", "No records found", 404);
            }
        } catch (Exception $e) {
            return $this->getResponse(null, "Failed", "Exception: " . $e->getMessage(), 500);
        }
    }

    public function gettask_status($status) {
        try {
            $sqlString = "SELECT * FROM todolist WHERE status = ?";
            $stmt = $this->pdo->prepare($sqlString);

            if (!$stmt) {
                return $this->getResponse(null, "Failed", "Failed to prepare statement", 500);
            }

            $stmt->bindParam(1, $status, PDO::PARAM_STR);

            if (!$stmt->execute()) {
                return $this->getResponse(null, "Failed", "Failed to execute statement", 500);
            }

            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if ($result) {
                return $this->getResponse($result, "Success", null, 200);
            } else {
                return $this->getResponse(null, "Failed", "No records found", 404);
            }
        } catch (Exception $e) {
            return $this->getResponse(null, "Failed", "Exception: " . $e->getMessage(), 500);
        }
    }


    public function get_jobs($id = null) {
        $condition = null;
        if ($id != null) {
            $condition = "JOB_ID=$id";
        }
        return $this->get_records("jobs", $condition);
    }

     // HOME FUNCTIONS

     public function get_properties() {
        $sqlString = "SELECT * FROM properties"; // Adjust the table name as needed
        $result = $this->executeQuery($sqlString);

        if ($result['code'] == 200) {
            return $this->sendPayload($result['data'], "success", "Successfully retrieved properties.", $result['code']);
        }

        return $this->sendPayload(null, "failed", "Failed to retrieve properties.", $result['code']);
    }

    public function getMedia() {
        $news = $this->get_records("news"); // Assuming you have a 'news' table
        $events = $this->get_records("events"); // Assuming you have an 'events' table
        $blogs = $this->get_records("blogs"); // Assuming you have a 'blogs' table
        $vlogs = $this->get_records("vlogs"); // Assuming you have a 'vlogs' table
    
        return array(
            "news" => $news['payload'],
            "events" => $events['payload'],
            "blogs" => $blogs['payload'],
            "vlogs" => $vlogs['payload']
        );
    }

    public function get_Media($type) {
        $table = '';
        switch ($type) {
            case 'news':
                $table = 'news'; // Adjust the table name as needed
                break;
            case 'events':
                $table = 'events'; // Adjust the table name as needed
                break;
            case 'blogs':
                $table = 'blogs'; // Adjust the table name as needed
                break;
            case 'vlogs':
                $table = 'vlogs'; // Adjust the table name as needed
                break;
            default:
                return $this->sendPayload(null, "failed", "Invalid media type.", 400);
        }
    
        $result = $this->executeQuery("SELECT * FROM $table");
    
        if ($result['code'] == 200) {
            return $this->sendPayload($result['data'], "success", "Successfully retrieved $type.", $result['code']);
        }
    
        return $this->sendPayload(null, "failed", "Failed to retrieve $type.", $result['code']);
    }

}
?>
