const express = require('express');
const pool = require('../database');

const router = express.Router();

// Get all messages
router.get('/messages', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM messages ORDER BY created_at DESC');
    res.json(rows);
  } catch (error) {
    console.error('Error fetching messages:', error.message); // Log the error
    res.status(500).send(error.message);
  }
});

// Post a message
router.post('/messages', async (req, res) => {
  const { content } = req.body;
  try {
    if (!content) {
      throw new Error('Message content cannot be empty');
    }
    const [result] = await pool.query('INSERT INTO messages (content) VALUES (?)', [content]);
    res.status(201).json({ id: result.insertId, content });
  } catch (error) {
    console.error('Error saving message:', error.message); // Log the error
    res.status(500).send(error.message);
  }
});

  

module.exports = router;