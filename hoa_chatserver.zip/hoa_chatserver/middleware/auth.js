const jwt = require("jsonwebtoken");

/**
 * Middleware to verify and decode a JWT token.
 * Ensures the token is valid and corresponds to the expected sender type.
 * Adds the decoded user data to `req.user` upon successful validation.
 *
 * @param {Object} req - The request object from the client.
 * @param {Object} res - The response object to send feedback to the client.
 * @param {Function} next - Callback to pass control to the next middleware.
 * @returns {void}
 */
function verifyToken(req, res, next) {
  // Extracts the token and sender type from the request
  const token = req.query.token || req.headers["authorization"];
  const senderType = req.query.senderType;

  // Ensures both token and sender type are provided
  if (!token || !senderType) {
    return res.status(403).send("Token and sender type are required.");
  }

  let secretKey;
  let expectedField;

  /**
   * Determines the secret key and expected field based on sender type.
   * `vendor` -> `JWT_SECRET_VENDOR` and `vendor_id`.
   * `user` -> `JWT_SECRET_USER` and `id`.
   */
  if (senderType === "vendor") {
    secretKey = process.env.JWT_SECRET_VENDOR;
    expectedField = "vendor_id";
  } else if (senderType === "user") {
    secretKey = process.env.JWT_SECRET_USER;
    expectedField = "id";
  } else {
    // Invalid sender type
    return res.status(400).send("Invalid sender type.");
  }

  try {
    // Verifies the token using the determined secret key
    const decoded = jwt.verify(token, secretKey);

    // Validates the expected field exists in the token payload
    if (!decoded.data || !decoded.data[expectedField]) {
      return res.status(401).send("Invalid token payload.");
    }

    // Attaches the decoded user data and sender type to the request object
    req.user = decoded.data;
    req.user.senderType = senderType;

    // Logs decoded token for debugging
    console.log("Decoded Token:", req.user);

    // Proceeds to the next middleware
    next();
  } catch (err) {
    // Handles errors during token verification (e.g., expired or malformed token)
    console.error("Token verification error:", err);
    return res.status(401).send("Invalid or expired token.");
  }
}

module.exports = verifyToken;
