require("dotenv").config();
const express = require("express");
const expressWs = require("express-ws");
const verifyToken = require("./middleware/auth");
const websocketRoutes = require("./routes/websocket");

const app = express();
expressWs(app);

// Middleware for authentication
app.use("/ws", verifyToken, websocketRoutes);

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`WebSocket server running on port ${PORT}`);
});