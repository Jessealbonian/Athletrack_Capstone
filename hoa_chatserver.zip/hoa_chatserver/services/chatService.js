const db = require("../utils/db");

/**
 * Saves a message to the database.
 * Determines the appropriate sender and recipient fields based on their types.
 *
 * @param {Object} params - The message details.
 * @param {string} params.senderId - ID of the sender (user or vendor).
 * @param {string} params.senderType - Type of the sender (`user` or `vendor`).
 * @param {string} params.recipientId - ID of the recipient (user or vendor).
 * @param {string} params.recipientType - Type of the recipient (`user` or `vendor`).
 * @param {string} params.message - The content of the message.
 * @returns {Promise<void>} Resolves when the message is saved.
 */
async function saveMessage({
  senderId,
  senderType,
  recipientId,
  recipientType,
  message,
}) {
  let senderUserId = null;
  let senderAdminId = null;

  // Determines sender fields based on sender type
  if (senderType === "user") {
    senderUserId = senderId;
  } else if (senderType === "admin") {
    senderAdminId = senderId;
  }

  let recipientUserId = null;
  let recipientAdminId = null;

  // Determines recipient fields based on recipient type
  if (recipientType === "user") {
    recipientUserId = recipientId;
  } else if (recipientType === "admin") {
    recipientAdminId = recipientId;
  }

  const query = `
    INSERT INTO messages (sender_user_id, sender_admin_id, sender_type, recipient_user_id, recipient_admin_id, message)
    VALUES (?, ?, ?, ?, ?, ?)
  `;

  await db.execute(query, [
    senderUserId,
    senderAdminId,
    senderType,
    recipientUserId,
    recipientAdminId,
    message,
  ]);
}

/**
 * Retrieves messages exchanged between a sender and a recipient.
 *
 * @param {Object} params - The query details.
 * @param {string} params.senderId - ID of the sender (user or vendor).
 * @param {string} params.senderType - Type of the sender (`user` or `vendor`).
 * @param {string} params.recipientId - ID of the recipient (user or vendor).
 * @returns {Promise<Array>} List of messages, ordered by creation time.
 */
async function getMessages({ senderId, senderType, recipientId }) {
  const query = `
    SELECT 
      id, 
      sender_user_id, 
      sender_admin_id, 
      sender_type, 
      recipient_user_id, 
      recipient_admin_id, 
      message, 
      created_at 
    FROM messages 
    WHERE 
      (
        (sender_admin_id = ? AND recipient_user_id = ?) -- Vendor to User
        OR
        (sender_user_id = ? AND recipient_admin_id = ?) -- User to Vendor
      )
    ORDER BY created_at ASC
  `;

  const params = [
    senderType === "admin" ? senderId : recipientId,
    senderType === "admin" ? recipientId : senderId,
    senderType === "user" ? senderId : recipientId,
    senderType === "user" ? recipientId : senderId,
  ];

  const [rows] = await db.execute(query, params);
  return rows;
}

/**
 * Retrieves a list of unique user contacts for a vendor based on exchanged messages.
 *
 * @param {string} adminId - ID of the vendor.
 * @returns {Promise<Array>} List of user contacts (ID and name).
 */
async function getAdminContacts(adminId) {
  const query = `
    SELECT DISTINCT u.user_id, u.name
    FROM messages m
    JOIN user u ON u.user_id = m.sender_user_id
    WHERE m.recipient_admin_id = ?
    AND m.sender_user_id IS NOT NULL
  `;

  const [rows] = await db.execute(query, [adminId]);
  return rows;
}

/**
 * Retrieves a list of unique vendor contacts for a user based on exchanged messages.
 *
 * @param {string} userId - ID of the user.
 * @returns {Promise<Array>} List of vendor contacts (ID and name).
 */
async function getUserContacts(userId) {
  const query = `
    SELECT DISTINCT v.admin_id, v.admin_name
    FROM messages m
    JOIN admin_acc v ON v.admin_id = m.sender_admin_id
    WHERE m.recipient_user_id = ?
    AND m.sender_admin_id IS NOT NULL
  `;

  const [rows] = await db.execute(query, [userId]);
  return rows;
}

module.exports = {
  saveMessage,
  getMessages,
  getAdminContacts,
  getUserContacts,
};
