const chatService = require("../services/chatService");
const db = require("../utils/db");

/* Mock the database execute function */
jest.mock("../utils/db");

describe("Chat Service - saveMessage", () => {
  beforeEach(() => {
    db.execute.mockClear();
  });

  it("should save a message from a user to a vendor", async () => {
    const mockMessage = {
      senderId: 3,
      senderType: "user",
      recipientId: 2,
      recipientType: "vendor",
      message: "Hello vendor, this is a test message.",
    };

    await chatService.saveMessage(mockMessage);

    expect(db.execute).toHaveBeenCalledWith(
      expect.stringContaining("INSERT INTO messages"),
      [
        mockMessage.senderId, // sender_user_id
        null, // sender_vendor_id
        mockMessage.senderType, // sender_type
        null, // recipient_user_id
        mockMessage.recipientId, // recipient_vendor_id
        mockMessage.message, // message
      ]
    );
  });

  it("should save a message from a vendor to a user", async () => {
    const mockMessage = {
      senderId: 2,
      senderType: "vendor",
      recipientId: 3,
      recipientType: "user",
      message: "Hello user, this is a test message.",
    };

    await chatService.saveMessage(mockMessage);

    expect(db.execute).toHaveBeenCalledWith(
      expect.stringContaining("INSERT INTO messages"),
      [
        null, // sender_user_id
        mockMessage.senderId, // sender_vendor_id
        mockMessage.senderType, // sender_type
        mockMessage.recipientId, // recipient_user_id
        null, // recipient_vendor_id
        mockMessage.message, // message
      ]
    );
  });

  it("should throw an error if senderType is invalid", async () => {
    const invalidMessage = {
      senderId: 1,
      senderType: "invalid",
      recipientId: 2,
      recipientType: "user",
      message: "This should fail.",
    };

    await expect(chatService.saveMessage(invalidMessage)).rejects.toThrow();
    expect(db.execute).not.toHaveBeenCalled();
  });
});
