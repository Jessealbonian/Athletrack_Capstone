const express = require("express");
const expressWs = require("express-ws");
const chatService = require("../services/chatService");

const router = express.Router();
expressWs(router);

/**
 * Object to manage WebSocket connections for users and vendors.
 * Organized by sender type (`user` or `vendor`) and their IDs.
 */
const connections = {
  user: {},
  vendor: {},
};

/**
 * Adds a WebSocket connection to the appropriate collection.
 * @param {string} type - Type of the sender (`user` or `vendor`).
 * @param {string} id - Unique identifier of the sender.
 * @param {WebSocket} ws - WebSocket connection.
 */
const addConnection = (type, id, ws) => {
  connections[type][id] = ws;
};

/**
 * Removes a WebSocket connection from the appropriate collection.
 * @param {string} type - Type of the sender (`user` or `vendor`).
 * @param {string} id - Unique identifier of the sender.
 */
const removeConnection = (type, id) => {
  delete connections[type][id];
};

/**
 * Sends a message to a recipient if they are connected.
 * @param {string} type - Recipient type (`user` or `vendor`).
 * @param {string} id - Recipient's unique identifier.
 * @param {Object} payload - Message payload to be sent.
 */
const sendMessageToRecipient = (type, id, payload) => {
  const recipientWs = connections[type][id];
  if (recipientWs) {
    recipientWs.send(JSON.stringify({ status: "success", message: payload }));
    console.log(`Message sent to ${type} ${id}`);
  } else {
    console.log(
      `${type.charAt(0).toUpperCase() + type.slice(1)} ${id} is not connected.`
    );
  }
};

/**
 * WebSocket route to handle chat functionality.
 * Manages message exchange, contact retrieval, and connection tracking.
 */
router.ws("/chat", (ws, req) => {
  const senderId = req.user.id || req.user.vendor_id;
  const senderType = req.user.senderType;

  // Store WebSocket connection
  addConnection(senderType, senderId, ws);

  /**
   * Event listener for WebSocket close event.
   * Removes the connection when the WebSocket is closed.
   */
  ws.on("close", (code, reason) => {
    console.log(`WebSocket closed. Code: ${code}, Reason: ${reason}`);
    removeConnection(senderType, senderId);
  });

  /**
   * Event listener for WebSocket message event.
   * Handles different actions such as sending messages, retrieving messages, and getting contacts.
   */
  ws.on("message", async (msg) => {
    try {
      const parsedMsg = JSON.parse(msg);
      const { action } = parsedMsg;

      switch (action) {
        case "getMessages": {
          /**
           * Retrieves chat messages between the sender and a specified recipient.
           */
          const { recipientId, recipientType } = parsedMsg;
          const messages = await chatService.getMessages({
            senderId,
            senderType,
            recipientId,
            recipientType,
          });
          ws.send(JSON.stringify({ status: "success", messages }));
          break;
        }
        case "sendMessage": {
          /**
           * Sends a chat message to a recipient and stores it in the database.
           */
          const { recipientId, recipientType, message } = parsedMsg;

          // Save the message in the database
          await chatService.saveMessage({
            senderId,
            senderType,
            recipientId,
            recipientType,
            message,
          });

          // Prepare message payload
          const messagePayload = {
            sender_user_id: senderType === "user" ? senderId : null,
            sender_vendor_id: senderType === "vendor" ? senderId : null,
            recipient_user_id: recipientType === "user" ? recipientId : null,
            recipient_vendor_id:
              recipientType === "vendor" ? recipientId : null,
            sender_type: senderType,
            message,
            created_at: new Date().toISOString(),
          };

          // Send the message to the recipient
          sendMessageToRecipient(recipientType, recipientId, messagePayload);

          // Echo the message back to the sender
          ws.send(
            JSON.stringify({ status: "success", message: messagePayload })
          );
          break;
        }
        case "getContacts": {
          /**
           * Retrieves contacts for a vendor.
           */
          if (senderType === "vendor") {
            const contacts = await chatService.getVendorContacts(senderId);
            ws.send(JSON.stringify({ status: "success", contacts }));
          } else {
            ws.send(
              JSON.stringify({ status: "error", error: "Invalid sender type" })
            );
          }
          break;
        }
        case "getUserContacts": {
          /**
           * Retrieves contacts for a user.
           */
          if (senderType === "user") {
            const contacts = await chatService.getUserContacts(senderId);
            ws.send(JSON.stringify({ status: "success", contacts }));
          } else {
            ws.send(
              JSON.stringify({ status: "error", error: "Invalid sender type" })
            );
          }
          break;
        }
        default:
          /**
           * Handles invalid or unsupported actions.
           */
          ws.send(JSON.stringify({ status: "error", error: "Invalid action" }));
      }
    } catch (err) {
      console.error("Error processing WebSocket message:", err);
      ws.send(JSON.stringify({ status: "error", error: err.message }));
    }
  });
});

module.exports = router;
